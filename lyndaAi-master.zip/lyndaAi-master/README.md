# LYNDA #
### An AI based virtual assitant ###


Lynda is an ai based desktop virtual assitant ,that uses snips-nlu engine to understand natural language and respond to user.
Lynda is able to respond smartly and currently do the following:
   1. open any website that the users tells her
   2. tell the weather in any location
   3. open any local program
   4. tell the top news headline
   5. play any music video
   6. search any query
   7. converse with user
 
 
## how to run ? ##

1. download the folder
2. install the dependecies from the requirement.txt
3. run Lynda.py

## Train the model ##

in order to train the model:
1.delete the model directory
2.Run Train.py


   
   
